package com.example.ridesharingdriversystem.business.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RideAssignDriverDto {

    private Long id;

    private Long driverId;

    private String driverName;

}
