package com.example.ridesharingdriversystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RideSharingDriverSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
