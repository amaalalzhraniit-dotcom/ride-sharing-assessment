package com.example.ridesharingcustomersystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RideSharingCustomerSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(RideSharingCustomerSystemApplication.class, args);
    }

}
