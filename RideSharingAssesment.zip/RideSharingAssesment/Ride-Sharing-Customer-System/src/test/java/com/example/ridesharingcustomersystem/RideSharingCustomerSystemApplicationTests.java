package com.example.ridesharingcustomersystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RideSharingCustomerSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
